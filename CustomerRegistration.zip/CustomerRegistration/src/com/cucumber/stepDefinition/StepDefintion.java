package com.cucumber.stepDefinition;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxBinary;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.testng.Assert;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDefintion {

	WebDriver driver;
	
	private static String customername = ("//*[contains(text(),'Customer Name')]//following-sibling::*//input[@type='text']");
	private static String age = ("//*[contains(text(),'Age')]//following-sibling::*//input[@type='text']");
	private static String address = ("//*[contains(text(),'Address')]//following-sibling::*//input[@name='address']");
	private static String phonenumber = ("//*[contains(text(),'Phone Number')]//following-sibling::*//input[@name='phonenumber']");
	private static String email = ("//*[contains(text(),'Email')]//following-sibling::*//input[@name='email']");
	
	private static String click = ("//*[@id='submit']");
	
	private static String Expected = ("//*[contains(text(),'Registered Succesfully')]");
	
	
	
	@Given("^User launches the Registration URL$")
	public void setUp() throws Throwable {
	    
		System.setProperty("webdriver.gecko.driver", "/usr/bin/geckodriver");
    	FirefoxBinary firefoxBinary = new FirefoxBinary();
    	firefoxBinary.addCommandLineOptions("--headless");
        FirefoxProfile profile=new FirefoxProfile();
    	FirefoxOptions firefoxOptions = new FirefoxOptions();
    	firefoxOptions.setBinary(firefoxBinary);
    	firefoxOptions.setProfile(profile);
        driver=new FirefoxDriver(firefoxOptions);		
		driver.get("http://webapps.tekstac.com/CustomerRegistration/Index");		
	
	}

	@When("^User enters name as \"([^\"]*)\", Age as \"([^\"]*)\", Address as  \"([^\"]*)\", Phone Number as \"([^\"]*)\" and Email as \"([^\"]*)\"$")
	public void testCustomerRegistration(String Name, String Age, String Address, String Number, String Email) throws Throwable {
		//Please fill the Required code
		driver.findElement(By.xpath(customername)).sendKeys(Name);
		driver.findElement(By.xpath(age)).sendKeys(Age);
		driver.findElement(By.xpath(address)).sendKeys(Address);
		driver.findElement(By.xpath(phonenumber)).sendKeys(Number);
		driver.findElement(By.xpath(email)).sendKeys(Email);
	}

	@When("^Click on Submit$")
	public void ClickSubmit() throws Throwable {
	    driver.findElement(By.xpath(click)).click();
	}

	@Then("^Validate the \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\" and \"([^\"]*)\"$")
	public void validateResult(String Name, String Age, String Address, String Number, String Email, String Result) throws Throwable {
			
		//Please fill the Required code
			
			if(!(Name.isEmpty()) && !(Age.isEmpty()) && !(Address.isEmpty()) && !(Number.isEmpty()) && !(Email.isEmpty()) && (Email.contains("@"))){
				String RegName = ("//*[contains(text(),'Name')]/following-sibling::*[contains(text(),'"+Name+"')]");
				By ELEM_REG_NAME = By.xpath(RegName);
				String RegisteredName =  driver.findElement(ELEM_REG_NAME).getText();
				
				String RegAge = ("//*[contains(text(),'Age')]/following-sibling::*[contains(text(),'"+Age+"')]");
				By ELEM_REG_AGE = By.xpath(RegAge);
				String RegisteredAge =  driver.findElement(ELEM_REG_AGE).getText();
				
				String RegAddress = ("//*[contains(text(),'Address')]/following-sibling::*[contains(text(),'"+Address+"')]");
				By ELEM_REG_ADD = By.xpath(RegAddress);
				String RegisteredAdd =  driver.findElement(ELEM_REG_ADD).getText();
				
				String RegNum = ("//*[contains(text(),'Phone')]/following-sibling::*[contains(text(),'"+Number+"')]");
				By ELEM_REG_NUM = By.xpath(RegNum);
				String RegisteredNum = driver.findElement(ELEM_REG_NUM).getText();
				
				String RegEmail = ("//*[contains(text(),'Email')]/following-sibling::*[contains(text(),'"+Email+"')]");
				By ELEM_REG_EMAIL = By.xpath(RegEmail);
				String RegisteredMail = driver.findElement(ELEM_REG_EMAIL).getText();
				
				System.out.println("Registered Succesfully");
				if (RegisteredName.contains(Name) && RegisteredAge.equals(Age) && RegisteredAdd.equals(Address) && RegisteredNum.equals(Number) && RegisteredMail.equals(Email)){
					if (driver.findElement(By.xpath("//*[contains(text(),'Registered Succesfully')]")).isDisplayed()){
						Assert.assertTrue(true);
					}
				}//Assert.assertTrue(false);	
			
			
			}else if(Address.isEmpty()){
				System.out.println("Addrerss field is empty");
				Thread.sleep(5000);
				if (driver.findElement(By.xpath("//*[contains(text(),'Address cannot be blank')]")).isDisplayed()){
					Thread.sleep(2000);
					Assert.assertTrue(true);
					
					//String mail = Email.substring(5, 5);
					
				}
			//Assert.assertTrue(false);
				
			}else if(!(Email.contains("@"))){
				System.out.println("Entered Email: "+Email);
				if(Email.equals("abc")){
					System.out.println("Invalid Email id");
					//System.out.println(!(Email.contains("@")));
					driver.findElement(By.xpath("//*[contains(text(),'Enter a valid email id')]")).isDisplayed();
					Assert.assertTrue(true);
				}
					
				}
				
			
			
			else if(Name.isEmpty()){
				System.out.println("Customer name is empty");
				driver.findElement(By.xpath("//*[contains(text(),'Customer name cannot be blank')]")).isDisplayed();
			}
		
		driver.quit();
		
		
		
	}

	
	
}
